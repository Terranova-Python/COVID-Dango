from django.contrib import admin
from django.urls import path

from mysite.core import views

urlpatterns = [
    path('home', views.home, name='home'),
    path('', views.landing, name='landing'),
    path('population-chart/', views.population_chart, name='population-chart'),
    path('population-radar', views.population_radar, name='population-radar'),
    path('pie-chart/', views.pie_chart, name='pie-chart'),
    path('admin/', admin.site.urls),
]
